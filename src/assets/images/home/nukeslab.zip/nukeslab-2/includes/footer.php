<section id="section-ten">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <h2>Are You Ready to GROW Your Business With Us?</h2>
          <div class="Are-You-btn">
            <button type="button" class="btn btn-primary">Get Your Free Marketing Plan</button>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section id="section-elev">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-4">
          <div class="log-ftr">
            <img src="assets/Images/log-futr.png" class="img-fluid" alt="...">
          </div>
          <div class="Extr-para">
            <p>
              Extraordinary Results from an extraordinary team. Click Then Convert. It’s not just our name, it’s a
              promise.
            </p>
          </div>
          <div class="icon-div-ftr">
            <a href=""><i class="bi bi-instagram"></i><i class="bi bi-globe"></i><i class="bi bi-twitter"></i><i
                class="bi bi-youtube"></i></a>
          </div>
        </div>
        <div class="col-md-2">
          <div class="agency-ftr-txt">
            <h6>Agency</h6>
            <p>Home</p>
            <p>Services</p>
            <p>Results</p>
            <p>Resources</p>
            <p>About us</p>
            <p>Careers <span class="We’re-hirin">We’re hiring</span> </p>
            <p>Contact us</p>
          </div>
        </div>
        <div class="col-md-3">
          <div class="agency-ftr-txt">
            <h6>Services</h6>
            <p>Paid Advertising</p>
            <p>Ad Operations and Analytics</p>
            <p>Conversion Rate Optimization</p>
            <p>Full Funnel Marketing</p>
            <p>Creative (Lab) Laboratory</p>
            <p>Website & Landing Pages</p>
          </div>
        </div>
        <div class="col-md-3">
          <div class="agency-ftr-txt">
            <h6>Reach us</h6>
            <div class="para-acnr-ftr">
              <p><a href=""><i class="bi bi-envelope-fill"></i>clientsuccess@clickthenconvert.com</a></p>
              <p><a href=""><i class="bi bi-tablet-fill"></i>1-855-602-0660</a></p>
              <p><a href=""><i class="bi bi-geo-alt-fill"></i>2719 Hollywood Blvd Suite 7000,Hollywood, FL 33021</a></p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section id="ftr-bottom">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="ftr-bot-flx">
          <div class="Click-the">
            <p>© 2022 Click Then convert. All rights reserved</p>
          </div>
          <div class="terms-ancr">
            <p><span class="bdr-rit-ftr"><a href="">Terms & Conditions</a></span> <span class="bdr-rit-ftr"><a href="">Privacy Policy</a></span> <span class="bdr-rit-ftr"><a href="">Sitemap</a></span><span class="Discla-ftr"><a href="">Disclaimer</a></span></p>
          </div>
        </div>
        </div>
      </div>
    </div>
  </section>